from flask import Flask, render_template, jsonify
import sqlite3

app = Flask(__name__)

DATABASE = "sales_management.db"


def get_db():
    connection = sqlite3.connect(DATABASE)
    connection.row_factory = sqlite3.Row
    return connection


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/api/dashboard")
def dashboard():

    connection = get_db()
    cursor = connection.cursor()

    # Total customers
    cursor.execute("SELECT COUNT(*) AS count FROM customers")
    customers = cursor.fetchone()["count"]

    # Total products
    cursor.execute("SELECT COUNT(*) AS count FROM products")
    products = cursor.fetchone()["count"]

    # Total orders
    cursor.execute("SELECT COUNT(*) AS count FROM orders")
    orders = cursor.fetchone()["count"]

    # Total completed sales
    cursor.execute("""
        SELECT COALESCE(SUM(total_amount), 0) AS total
        FROM orders
        WHERE status = 'COMPLETED'
    """)
    revenue = cursor.fetchone()["total"]

    # Recent orders
    cursor.execute("""
        SELECT
            orders.order_id,
            customers.name AS customer_name,
            orders.order_date,
            orders.status,
            orders.total_amount
        FROM orders
        INNER JOIN customers
            ON orders.customer_id = customers.customer_id
        ORDER BY orders.order_id DESC
        LIMIT 10
    """)

    recent_orders = [dict(row) for row in cursor.fetchall()]

    connection.close()

    return jsonify({
        "customers": customers,
        "products": products,
        "orders": orders,
        "revenue": revenue,
        "recent_orders": recent_orders
    })


if __name__ == "__main__":
    app.run(debug=True)