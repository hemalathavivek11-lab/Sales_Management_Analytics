import sqlite3

DATABASE = "sales_management.db"


def get_connection():
    connection = sqlite3.connect(DATABASE)
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


# -------------------------
# CREATE / INSERT
# -------------------------
def add_customer():
    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        INSERT INTO customers
        (name, email, city, signup_date)
        VALUES (?, ?, ?, ?)
    """, (
        "Test Customer",
        "test@gmail.com",
        "Chennai",
        "2026-03-25"
    ))

    connection.commit()
    print("Customer inserted successfully!")

    connection.close()


# -------------------------
# READ / SELECT
# -------------------------
def view_customers():
    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT customer_id, name, email, city, signup_date
        FROM customers
    """)

    customers = cursor.fetchall()

    print("\nCUSTOMER LIST")
    print("-" * 70)

    for customer in customers:
        print(customer)

    connection.close()


# -------------------------
# UPDATE
# -------------------------
def update_customer():
    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        UPDATE customers
        SET city = ?
        WHERE email = ?
    """, (
        "Madurai",
        "test@gmail.com"
    ))

    connection.commit()

    print("Customer updated successfully!")

    connection.close()


# -------------------------
# DELETE
# -------------------------
def delete_customer():
    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        DELETE FROM customers
        WHERE email = ?
    """, (
        "test@gmail.com",
    ))

    connection.commit()

    print("Customer deleted successfully!")

    connection.close()


# -------------------------
# RUN CRUD OPERATIONS
# -------------------------

print("\n1. INSERT")
add_customer()

print("\n2. SELECT")
view_customers()

print("\n3. UPDATE")
update_customer()

print("\n4. SELECT AFTER UPDATE")
view_customers()

print("\n5. DELETE")
delete_customer()

print("\n6. SELECT AFTER DELETE")
view_customers()