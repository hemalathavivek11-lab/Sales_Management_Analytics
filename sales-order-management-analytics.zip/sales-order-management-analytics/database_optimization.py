import sqlite3

DATABASE = "sales_management.db"

connection = sqlite3.connect(DATABASE)
cursor = connection.cursor()

# ==========================================
# 1. CREATE SALES SUMMARY VIEW
# ==========================================

cursor.execute("DROP VIEW IF EXISTS sales_summary")

cursor.execute("""
CREATE VIEW sales_summary AS
SELECT
    customers.name AS customer_name,
    orders.order_id,
    orders.order_date,
    orders.status,
    orders.total_amount
FROM customers
INNER JOIN orders
    ON customers.customer_id = orders.customer_id
WHERE orders.status = 'COMPLETED'
""")

print("Sales summary view created successfully!")


# ==========================================
# 2. CREATE PRODUCT SALES VIEW
# ==========================================

cursor.execute("DROP VIEW IF EXISTS product_sales")

cursor.execute("""
CREATE VIEW product_sales AS
SELECT
    products.product_name,
    products.category,
    SUM(order_items.quantity) AS units_sold,
    SUM(order_items.quantity * order_items.unit_price) AS revenue
FROM products
INNER JOIN order_items
    ON products.product_id = order_items.product_id
INNER JOIN orders
    ON order_items.order_id = orders.order_id
WHERE orders.status = 'COMPLETED'
GROUP BY products.product_id, products.product_name, products.category
""")

print("Product sales view created successfully!")


# ==========================================
# 3. CREATE INDEXES
# ==========================================

cursor.execute("""
CREATE INDEX IF NOT EXISTS idx_orders_customer
ON orders(customer_id)
""")

cursor.execute("""
CREATE INDEX IF NOT EXISTS idx_orders_date
ON orders(order_date)
""")

cursor.execute("""
CREATE INDEX IF NOT EXISTS idx_order_items_product
ON order_items(product_id)
""")

print("Indexes created successfully!")


# ==========================================
# 4. TEST SALES SUMMARY VIEW
# ==========================================

print("\nSALES SUMMARY VIEW")
print("-" * 70)

cursor.execute("""
SELECT *
FROM sales_summary
""")

for row in cursor.fetchall():
    print(row)


# ==========================================
# 5. TEST PRODUCT SALES VIEW
# ==========================================

print("\nPRODUCT SALES VIEW")
print("-" * 70)

cursor.execute("""
SELECT *
FROM product_sales
ORDER BY revenue DESC
""")

for row in cursor.fetchall():
    print(row)


# ==========================================
# 6. QUERY OPTIMIZATION
# ==========================================

print("\nQUERY EXECUTION PLAN")
print("-" * 70)

cursor.execute("""
EXPLAIN QUERY PLAN
SELECT *
FROM orders
WHERE customer_id = 1
""")

for row in cursor.fetchall():
    print(row)


connection.commit()
connection.close()

print("\nDatabase optimization completed successfully!")