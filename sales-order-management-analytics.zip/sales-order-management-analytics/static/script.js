async function loadDashboard() {

    try {

        const response = await fetch("/api/dashboard");

        const data = await response.json();


        // SUMMARY CARDS

        document.getElementById("customers").textContent =
            data.customers;

        document.getElementById("products").textContent =
            data.products;

        document.getElementById("orders").textContent =
            data.orders;

        document.getElementById("revenue").textContent =
            "₹" + Number(data.revenue).toLocaleString("en-IN");


        // RECENT ORDERS

        const table = document.getElementById("ordersTable");

        table.innerHTML = "";


        data.recent_orders.forEach(order => {

            const row = document.createElement("tr");

            row.innerHTML = `
                <td>${order.order_id}</td>
                <td>${order.customer_name}</td>
                <td>${order.order_date}</td>
                <td>${order.status}</td>
                <td>₹${Number(order.total_amount).toLocaleString("en-IN")}</td>
            `;

            table.appendChild(row);

        });


        // SIMPLE SALES CHART

        const labels = data.recent_orders.map(
            order => "Order " + order.order_id
        );

        const values = data.recent_orders.map(
            order => order.total_amount
        );


        new Chart(
            document.getElementById("salesChart"),
            {
                type: "bar",

                data: {
                    labels: labels,

                    datasets: [{
                        label: "Order Amount",

                        data: values
                    }]
                },

                options: {
                    responsive: true,

                    plugins: {
                        legend: {
                            display: true
                        }
                    }
                }
            }
        );

    } catch (error) {

        console.error("Dashboard error:", error);

    }

}


loadDashboard();