import sqlite3

DATABASE = "sales_management.db"

connection = sqlite3.connect(DATABASE)

cursor = connection.cursor()

# -------------------------
# CUSTOMERS
# -------------------------
customers = [
    (1, "Arun Kumar", "arun@gmail.com", "Chennai", "2026-01-10"),
    (2, "Priya Sharma", "priya@gmail.com", "Bangalore", "2026-01-12"),
    (3, "Rahul Raj", "rahul@gmail.com", "Chennai", "2026-01-15"),
    (4, "Divya S", "divya@gmail.com", "Coimbatore", "2026-01-20"),
    (5, "Karthik M", "karthik@gmail.com", "Madurai", "2026-01-25"),
    (6, "Meena Devi", "meena@gmail.com", "Salem", "2026-02-01"),
    (7, "Vijay Kumar", "vijay@gmail.com", "Trichy", "2026-02-05"),
    (8, "Anitha R", "anitha@gmail.com", "Chennai", "2026-02-10")
]

cursor.executemany("""
INSERT OR IGNORE INTO customers
(customer_id, name, email, city, signup_date)
VALUES (?, ?, ?, ?, ?)
""", customers)


# -------------------------
# PRODUCTS
# -------------------------
products = [
    (1, "Laptop", "Electronics", 55000, 20),
    (2, "Wireless Mouse", "Accessories", 800, 50),
    (3, "Keyboard", "Accessories", 1500, 40),
    (4, "Headphones", "Electronics", 2500, 30),
    (5, "USB Cable", "Accessories", 400, 100),
    (6, "Monitor", "Electronics", 12000, 15),
    (7, "Webcam", "Electronics", 3500, 25),
    (8, "Laptop Bag", "Accessories", 1800, 35)
]

cursor.executemany("""
INSERT OR IGNORE INTO products
(product_id, product_name, category, price, stock)
VALUES (?, ?, ?, ?, ?)
""", products)


# -------------------------
# ORDERS
# -------------------------
orders = [
    (1, 1, "2026-03-01", "COMPLETED", 55800),
    (2, 2, "2026-03-02", "COMPLETED", 4000),
    (3, 3, "2026-03-04", "PENDING", 2500),
    (4, 4, "2026-03-05", "COMPLETED", 1500),
    (5, 1, "2026-03-07", "COMPLETED", 2900),
    (6, 5, "2026-03-10", "CANCELLED", 3500),
    (7, 6, "2026-03-12", "COMPLETED", 12000),
    (8, 7, "2026-03-15", "COMPLETED", 7300),
    (9, 2, "2026-03-18", "COMPLETED", 1800),
    (10, 1, "2026-03-20", "COMPLETED", 6300)
]

cursor.executemany("""
INSERT OR IGNORE INTO orders
(order_id, customer_id, order_date, status, total_amount)
VALUES (?, ?, ?, ?, ?)
""", orders)


# -------------------------
# ORDER ITEMS
# -------------------------
order_items = [
    (1, 1, 1, 1, 55000),
    (2, 1, 2, 1, 800),
    (3, 2, 4, 1, 2500),
    (4, 2, 3, 1, 1500),
    (5, 3, 4, 1, 2500),
    (6, 4, 3, 1, 1500),
    (7, 5, 4, 1, 2500),
    (8, 5, 2, 1, 400),
    (9, 6, 7, 1, 3500),
    (10, 7, 6, 1, 12000),
    (11, 8, 7, 1, 3500),
    (12, 8, 3, 1, 1500),
    (13, 9, 8, 1, 1800),
    (14, 10, 6, 1, 5500),
    (15, 10, 2, 1, 800)
]

cursor.executemany("""
INSERT OR IGNORE INTO order_items
(order_item_id, order_id, product_id, quantity, unit_price)
VALUES (?, ?, ?, ?, ?)
""", order_items)


# -------------------------
# PAYMENTS
# -------------------------
payments = [
    (1, 1, "2026-03-01", 55800, "PAID"),
    (2, 2, "2026-03-02", 4000, "PAID"),
    (3, 3, "2026-03-04", 2500, "PENDING"),
    (4, 4, "2026-03-05", 1500, "PAID"),
    (5, 5, "2026-03-07", 2900, "PAID"),
    (6, 6, "2026-03-10", 3500, "REFUNDED"),
    (7, 7, "2026-03-12", 12000, "PAID"),
    (8, 8, "2026-03-15", 7300, "PAID"),
    (9, 9, "2026-03-18", 1800, "PAID"),
    (10, 10, "2026-03-20", 6300, "PAID")
]

cursor.executemany("""
INSERT OR IGNORE INTO payments
(payment_id, order_id, payment_date, amount, payment_status)
VALUES (?, ?, ?, ?, ?)
""", payments)


connection.commit()
connection.close()

print("Sample data inserted successfully!")