import sqlite3

DATABASE = "sales_management.db"


def run_query(title, query):
    connection = sqlite3.connect(DATABASE)
    cursor = connection.cursor()

    print("\n" + "=" * 80)
    print(title)
    print("=" * 80)

    cursor.execute(query)

    columns = [description[0] for description in cursor.description]
    print(" | ".join(columns))
    print("-" * 80)

    for row in cursor.fetchall():
        print(row)

    connection.close()


# 1. SUBQUERY
run_query(
    "1. CUSTOMERS WITH ABOVE-AVERAGE SALES",
    """
    SELECT name
    FROM customers
    WHERE customer_id IN (
        SELECT customer_id
        FROM orders
        WHERE total_amount > (
            SELECT AVG(total_amount)
            FROM orders
            WHERE status = 'COMPLETED'
        )
        AND status = 'COMPLETED'
    );
    """
)


# 2. CTE
run_query(
    "2. SALES USING CTE",
    """
    WITH customer_sales AS (
        SELECT
            customer_id,
            SUM(total_amount) AS total_sales
        FROM orders
        WHERE status = 'COMPLETED'
        GROUP BY customer_id
    )
    SELECT
        customers.name,
        customer_sales.total_sales
    FROM customer_sales
    INNER JOIN customers
        ON customers.customer_id = customer_sales.customer_id
    ORDER BY customer_sales.total_sales DESC;
    """
)


# 3. CASE STATEMENT
run_query(
    "3. ORDER VALUE CLASSIFICATION",
    """
    SELECT
        order_id,
        total_amount,
        CASE
            WHEN total_amount >= 10000 THEN 'HIGH VALUE'
            WHEN total_amount >= 5000 THEN 'MEDIUM VALUE'
            ELSE 'LOW VALUE'
        END AS order_category
    FROM orders
    ORDER BY total_amount DESC;
    """
)


# 4. RANKING
run_query(
    "4. CUSTOMER SALES RANKING",
    """
    SELECT
        customers.name,
        SUM(orders.total_amount) AS total_sales,
        RANK() OVER (
            ORDER BY SUM(orders.total_amount) DESC
        ) AS sales_rank
    FROM customers
    INNER JOIN orders
        ON customers.customer_id = orders.customer_id
    WHERE orders.status = 'COMPLETED'
    GROUP BY customers.customer_id, customers.name;
    """
)


# 5. ROW NUMBER
run_query(
    "5. ORDER RANKING",
    """
    SELECT
        order_id,
        total_amount,
        ROW_NUMBER() OVER (
            ORDER BY total_amount DESC
        ) AS order_rank
    FROM orders;
    """
)


# 6. RUNNING TOTAL
run_query(
    "6. RUNNING SALES TOTAL",
    """
    SELECT
        order_date,
        total_amount,
        SUM(total_amount) OVER (
            ORDER BY order_date
        ) AS running_total
    FROM orders
    WHERE status = 'COMPLETED'
    ORDER BY order_date;
    """
)


# 7. MONTHLY SALES
run_query(
    "7. MONTHLY SALES",
    """
    SELECT
        strftime('%Y-%m', order_date) AS month,
        SUM(total_amount) AS monthly_sales,
        COUNT(order_id) AS number_of_orders
    FROM orders
    WHERE status = 'COMPLETED'
    GROUP BY strftime('%Y-%m', order_date)
    ORDER BY month;
    """
)


# 8. TOP 3 PRODUCTS
run_query(
    "8. TOP 3 PRODUCTS",
    """
    SELECT
        products.product_name,
        SUM(order_items.quantity) AS units_sold
    FROM products
    INNER JOIN order_items
        ON products.product_id = order_items.product_id
    INNER JOIN orders
        ON order_items.order_id = orders.order_id
    WHERE orders.status = 'COMPLETED'
    GROUP BY products.product_id, products.product_name
    ORDER BY units_sold DESC
    LIMIT 3;
    """
)