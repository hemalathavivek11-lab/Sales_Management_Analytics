import sqlite3

DATABASE = "sales_management.db"


def run_query(title, query):
    connection = sqlite3.connect(DATABASE)
    cursor = connection.cursor()

    print("\n" + "=" * 80)
    print(title)
    print("=" * 80)

    cursor.execute(query)

    # Print column names
    columns = [description[0] for description in cursor.description]
    print(" | ".join(columns))
    print("-" * 80)

    for row in cursor.fetchall():
        print(row)

    connection.close()


# 1. INNER JOIN
run_query(
    "1. CUSTOMER ORDERS - INNER JOIN",
    """
    SELECT
        customers.name AS customer_name,
        orders.order_id,
        orders.order_date,
        orders.status,
        orders.total_amount
    FROM customers
    INNER JOIN orders
        ON customers.customer_id = orders.customer_id
    ORDER BY orders.order_id;
    """
)


# 2. MULTI-TABLE JOIN
run_query(
    "2. ORDER DETAILS - MULTI TABLE JOIN",
    """
    SELECT
        orders.order_id,
        customers.name AS customer_name,
        products.product_name,
        order_items.quantity,
        order_items.unit_price
    FROM orders
    INNER JOIN customers
        ON orders.customer_id = customers.customer_id
    INNER JOIN order_items
        ON orders.order_id = order_items.order_id
    INNER JOIN products
        ON order_items.product_id = products.product_id
    ORDER BY orders.order_id;
    """
)


# 3. TOTAL REVENUE
run_query(
    "3. TOTAL SALES REVENUE",
    """
    SELECT
        SUM(total_amount) AS total_revenue
    FROM orders
    WHERE status = 'COMPLETED';
    """
)


# 4. ORDER COUNT
run_query(
    "4. TOTAL NUMBER OF ORDERS",
    """
    SELECT
        COUNT(*) AS total_orders
    FROM orders;
    """
)


# 5. AVERAGE ORDER VALUE
run_query(
    "5. AVERAGE ORDER VALUE",
    """
    SELECT
        AVG(total_amount) AS average_order_value
    FROM orders
    WHERE status = 'COMPLETED';
    """
)


# 6. SALES BY CUSTOMER
run_query(
    "6. SALES BY CUSTOMER",
    """
    SELECT
        customers.name AS customer_name,
        COUNT(orders.order_id) AS number_of_orders,
        SUM(orders.total_amount) AS total_sales
    FROM customers
    INNER JOIN orders
        ON customers.customer_id = orders.customer_id
    WHERE orders.status = 'COMPLETED'
    GROUP BY customers.customer_id, customers.name
    ORDER BY total_sales DESC;
    """
)


# 7. SALES BY PRODUCT
run_query(
    "7. SALES BY PRODUCT",
    """
    SELECT
        products.product_name,
        SUM(order_items.quantity) AS units_sold,
        SUM(order_items.quantity * order_items.unit_price) AS product_revenue
    FROM products
    INNER JOIN order_items
        ON products.product_id = order_items.product_id
    INNER JOIN orders
        ON order_items.order_id = orders.order_id
    WHERE orders.status = 'COMPLETED'
    GROUP BY products.product_id, products.product_name
    ORDER BY product_revenue DESC;
    """
)


# 8. GROUP BY CATEGORY
run_query(
    "8. SALES BY PRODUCT CATEGORY",
    """
    SELECT
        products.category,
        COUNT(DISTINCT orders.order_id) AS number_of_orders,
        SUM(order_items.quantity * order_items.unit_price) AS category_revenue
    FROM products
    INNER JOIN order_items
        ON products.product_id = order_items.product_id
    INNER JOIN orders
        ON order_items.order_id = orders.order_id
    WHERE orders.status = 'COMPLETED'
    GROUP BY products.category
    ORDER BY category_revenue DESC;
    """
)


# 9. HAVING
run_query(
    "9. CUSTOMERS WITH SALES ABOVE 5000",
    """
    SELECT
        customers.name AS customer_name,
        SUM(orders.total_amount) AS total_sales
    FROM customers
    INNER JOIN orders
        ON customers.customer_id = orders.customer_id
    WHERE orders.status = 'COMPLETED'
    GROUP BY customers.customer_id, customers.name
    HAVING SUM(orders.total_amount) > 5000
    ORDER BY total_sales DESC;
    """
)


# 10. LEFT JOIN
run_query(
    "10. ALL CUSTOMERS INCLUDING CUSTOMERS WITHOUT ORDERS",
    """
    SELECT
        customers.name AS customer_name,
        COUNT(orders.order_id) AS number_of_orders
    FROM customers
    LEFT JOIN orders
        ON customers.customer_id = orders.customer_id
    GROUP BY customers.customer_id, customers.name
    ORDER BY number_of_orders DESC;
    """
)