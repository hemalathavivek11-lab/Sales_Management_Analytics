import sqlite3

connection = sqlite3.connect("sales_management.db")
cursor = connection.cursor()

print("\nCUSTOMERS")
for row in cursor.execute("SELECT * FROM customers"):
    print(row)

print("\nPRODUCTS")
for row in cursor.execute("SELECT * FROM products"):
    print(row)

print("\nORDERS")
for row in cursor.execute("SELECT * FROM orders"):
    print(row)

print("\nPAYMENTS")
for row in cursor.execute("SELECT * FROM payments"):
    print(row)

connection.close()